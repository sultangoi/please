# Cuphead-Clone
Personal Side Project Cuphead Clone

2D Run and Gun Shooter

#Installation
1. Download and Import Cuphead.zip into Unity2D editor.
2. Pull Github changes into project folder.
3. Compile and build from Unity.
