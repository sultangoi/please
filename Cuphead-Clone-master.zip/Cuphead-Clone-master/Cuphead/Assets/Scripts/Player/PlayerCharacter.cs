﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerCharacter : MonoBehaviour
{
    [SerializeField] GameObject[] firingModes;
    private int currentMode = 0;

    void Start()
    {
        
    }

    void Update()
    {
        
    }
}
